 @extends('templates.appro') 

@section('document')

@include('dashboard.blade.php');

@endsection